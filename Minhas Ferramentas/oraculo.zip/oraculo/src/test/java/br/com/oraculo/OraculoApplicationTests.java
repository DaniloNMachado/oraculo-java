package br.com.oraculo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OraculoApplicationTests {

	@Test
	void contextLoads() {
	}

}
